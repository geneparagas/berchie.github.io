<!doctype html>

<!--Begin Html-->
<html dir="ltr" lang="en-US">

<!--Begin Head-->
<head>

<!--Meta Tags-->
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<title>Contact Us | Systems Integration Philippines 2014 | Systems Integration Philippines</title>


<link rel='stylesheet' id='contact-form-7-css'  href='css/style2.css' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='css/style.css' type='text/css' media='screen' />
<link rel='stylesheet' id='slideshow-css'  href='css/slideshow.css' type='text/css' media='screen' />
<link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css' type='text/css' media='screen' />
<link rel='stylesheet' id='shortcodes-css'  href='css/shortcodes.css' type='text/css' media='screen' />
<link rel='stylesheet' id='widgets-css'  href='css/widgets.css' type='text/css' media='screen' />
<link rel='stylesheet' id='prettyphoto-css'  href='css/prettyphoto.css' type='text/css' media='screen' />
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery.scripts.js'></script>
<script type='text/javascript' src='js/html5.min.js'></script>
<script type='text/javascript' src='js/custom.js'></script>


<!--Extend CSS-->
<style type="text/css">

		#slides-wrap-home .slider-pagination { left: 464px; }
		.site-logo, .site-name { margin-top: 9px; margin-bottom: 18px; }
		.top-media { margin-top: 45px; }
		.ddsmoothmenu ul li ul li a { width: 160px; }
		body { font-family: "Helvetica Neue", Arial, Helvetica, sans-serif; }
		nav { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		h1, h2, h3, h4, h5, h6 { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		.meta { font-family: "Mako", Helvetica, Arial, serif, sans-serif; }
		#top-menu ul.drop-menu li a { font-size: 12px; }
		#top-menu ul.drop-menu li ul li a { font-size: 12px; }
		.post-content h1  { font-size: 24px; }
		.post-content h2  { font-size: 20px; }
		.post-content h3  { font-size: 16px; }
		.post-content h4  { font-size: 14px; }
		.post-content h5  { font-size: 12px; }
		.post-content h6  { font-size: 10px; }
		body { color: #666666; }
		a { color: #333333; }
		a:hover,
		#top-menu ul.drop-menu li a:hover,
		#top-menu ul.drop-menu li a.selected,
		#top-menu ul.drop-menu li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-item a,
		#top-menu ul.drop-menu li.current_page_parent a,
		#top-menu ul.drop-menu li.current-menu-parent a,
		.blog-list li .post-meta a:hover,
		.post-blog-single .post-meta a:hover,
		.comment-meta .fn a:hover,
		.comment-form-author span,
		.comment-form-email span,
		.widget-tweets li .date a:hover,
		.widget-posts li .post-meta a:hover,
		.widget-portfolios li .post-meta a:hover,
		.sc-slider-list li .meta a:hover,
		.sc-slider-list li .skills a:hover,
		.home-service-box .title,
		.commentlist li .reply:hover,
		.sc-pricing-table-wrap .pricing-item .price-currency { color: #4e2350; }
		.post-more a:hover,
		.blog-list li .more-link:hover,
		.post-portfolio-single .single-post-pagenation li a:hover,
		.comment-form-author input[type="text"]:focus,
		.comment-form-email input[type="text"]:focus,
		.comment-form-url input[type="text"]:focus,
		#commentform .comment-form-comment:focus,
		#commentform .form-submit input[type="submit"]:hover,
		.wp-pagenavi a:hover, 
		.wp-pagenavi span.current,
		.pagination a:hover,
		.pagination span.current,
		.normal-pagination span a:hover,
		.comment-pagination a:hover, 
		.comment-pagination span.current,
		.sortable-menu li.current-cat a,
		.sortable-menu li.active a,
		.sortable-menu li a:hover,
		.post-single-contact .input-block input:focus,
		.post-single-contact .textarea-block #contact-message:focus,
		.post-single-contact .submit-block input[type="submit"]:hover,
		.jcarousel-prev:hover, .jcarousel-prev:focus, .jcarousel-prev:active,
		.jcarousel-next:hover, .jcarousel-next:focus, .jcarousel-next:active,
		.sc-tabs-wrap .tabs li .active,
		.sc-pricing-table-wrap .pricing-item .button-wrap a:hover { background-color: #4e2350; }
		.jcarousel-prev-disabled, .jcarousel-prev-disabled:hover,
		.jcarousel-prev-disabled:focus, .jcarousel-prev-disabled:active,
		.jcarousel-next-disabled, .jcarousel-next-disabled:hover,
		.jcarousel-next-disabled:focus, .jcarousel-next-disabled:active { background-color: #EEE; }
		.post-thumb-border .border { border: 5px solid #4e2350; }

		#top-menu ul.drop-menu li.current_page_parent ul li a,
		#top-menu ul.drop-menu li.current-menu-parent ul li a { color: #333; }

		#top-menu ul.drop-menu li.current_page_parent ul li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-parent ul li.current-menu-item a { color: #4e2350; }
		

			body { background: url(images/bg_new1.jpg) no-repeat center center fixed #161616; -webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover; } 
			
			
			
</style>

		<!--Custom CSS-->
		
		<link type="text/css" rel="stylesheet" href="css/custom.css" media="screen" />
		<link href='css/css2.css' rel='stylesheet' type='text/css'>
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="shortcut icon" href="images/fav-iffina.png" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />

<!--End head-->
</head>

<!--Begin Body-->
<body class="home page page-id-369 page-template page-template-template-home-php wp-front-page">

<div id="page" class="hfeed">

<!--Begin Header-->
<header id="site-head">
	<div class="clearfix col-box">
	<div class="site-logo">
<a href="index.html"><img src="images/logo_sip.png" /></a>
</div>

		<div class="site-logo2"><img src="images/datevenue.png"><br>
        <a href="https://www.facebook.com/pages/Systems-Integration-Philippines-Expo/496851847036047" onMouseOver="document.fb.src='images/fb2.png'" onMouseOut="document.fb.src='images/fb1.png'">
        <img src="images/fb1.png" style="padding-left:90px; padding-top:5px;" name="fb"></a>
        <a href="https://twitter.com/SIPExhibit" onMouseOver="document.twit.src='images/twit2.png'" onMouseOut="document.twit.src='images/twit1.png'">
        <img src="images/twit1.png" style="padding-left:5px; padding-top:5px;" name="twit"></a>
      </div>

	</div>
	<nav id="top-menu" class="ddsmoothmenu"><ul id="menu-2013menu" class="drop-menu"><li id="menu-item-628" class="menu-item menu-item-type-post_type menu-item-object-page page_item page-item-369"><a href="index.html">HOME</a></li>
<li id="menu-item-589" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-589 "><a href="about.php">ABOUT</a>
</li>
<li id="menu-item-620" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-620"><a href="shows.php">SHOWS</a>
</li>
<li id="menu-item-596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-596"><a href="SIP 2013 - Detailed Schedule of Activities 081013.pdf">ACTIVITIES</a></li>
<li id="menu-item-596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-596"><a href="reg.html">REGISTER</a></li>
<li id="menu-item-596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-596"><a href="download.html">DOWNLOADS</a></li>
<!--<li id="menu-item-596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-596"><a href="feature.html">SPECIAL FEATURE</a></li>-->
<li id="menu-item-595" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-595 current_page_item menu-item-595"><a href="contact.php">CONTACT US</a></li>
</ul></nav><!--End Header-->
</header>

<div id="main" class="fullwidth">

<!--Begin Content-->
<article id="content"><!--end slides-wrap--><div style="margin-top: 70px;"></div>
<div class="col-box home-service-box clearfix"><div class="col-1-4 col-first clearfix"><h1 class="title">&nbsp;</h1>
<img src="images/GESI logo.png">
<p class="desc">GLOBAL-LINK EXHIBITIONS SPECIALIST, INC.<br>
Unit 1004 Antel 2000 Corporate Centre<br>
121 Valero St. Salcedo Village, Makati City, 1227 Philippines<br>
Tel. No. : +632 7508588 to 92<br>
Fax No. : +632 7508588 / 887-1305<br>
Email: <a href="mailto:info@gesi.com.ph" style="text-decoration:underline;">info@gesi.com.ph</a>
</p><br>



</div></div><div style="margin-top: 200px;"></div>
</article>
<!--End Content-->

</div>
<!-- #main -->
<footer>

<!--Begin Footer Widget--><!--End Footer Widget-->

<div class="footer-message">
<p>
<a href="index.html" style="text-decoration:underline;">Home</a> | <a href="about.php" style="text-decoration:underline;">About</a> | <a href="shows.php" style="text-decoration:underline;">Shows</a> | <a href="reg.html" style="text-decoration:underline;">Register</a> | <a href="contact.php" style="text-decoration:underline;">Contact Us</a></p><br>
<p>
Copyright &copy;  <a href="http://www.gesi.com.ph">Systems Integration Philippines 2015</a> - GLOBAL-LINK EXHIBITIONS SPECIALIST, INC. - MIS.</p>
</div>
<!--end # footer message-->
<!--End Footer-->
</footer>

</div>
<!-- # page -->

<div id="toTop">Back to top</div>


	<div style="display:none">
	</div>
<script type="text/javascript">
//<![CDATA[
ddsmoothmenu.init({
mainmenuid: "top-menu", 
orientation: "h", 
classname: "ddsmoothmenu", 
contentsource: "markup" 
});
//]]>
</script>

<script type='text/javascript' src='js/jquery.form.js'></script>



<script src="js/e-201319.js" type="text/javascript"></script>
	<script type="text/javascript">
	st_go({v:'ext',j:'1:1.4.2',blog:'38302682',post:'369'});
	var load_cmc = function(){linktracker_init(38302682,369,2);};
	if ( typeof addLoadEvent != 'undefined' ) addLoadEvent(load_cmc);
	else load_cmc();
	</script><!--End Body-->
</body>

<!--End Html-->
</html>