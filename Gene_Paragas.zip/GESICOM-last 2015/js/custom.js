/*-----------------------------------------------------------------------------------*/
//	Common
/*-----------------------------------------------------------------------------------*/
jQuery(document).ready(function(){
	home_slides_js();
	theme_jcarousel();
	theme_slogan_slider();
	theme_content_slideshow();
	portfolio_list_slideshow_nav();
	external_link();
	go_to_top();
	prettyPhoto();
	theme_top_media();
	theme_image_preload();
	theme_image_hover();
	theme_tabs();
	theme_toggles();
	theme_accordions();
	theme_portfolio_quicksand();
	theme_responsive_images();
});



/*-----------------------------------------------------------------------------------*/
//	Slides JS
/*-----------------------------------------------------------------------------------*/
function home_slides_js(){
	if( jQuery().slides) {
	    var slider = jQuery('#slides-wrap-home');
		slider.slides({
	        preload: true,
			preloadImage: slider.attr('data-loader'), 
			generatePagination: true,
			generateNextPrev: true,
			paginationClass: 'slider-pagination',
			next: 'slider-next',
			prev: 'slider-prev',
			effect: slider.attr('data-effect'), 
			play: slider.attr('data-speed'), 
			pause: 350,
			crossfade: true,
			hoverPause: true,
			autoHeight: true,
			bigTarget: false
		});
	}

	jQuery('.slider-next, .slider-prev').css('opacity','0');

	jQuery('#slides-wrap-home').hover(function(e){
		jQuery(this).find('.slider-next, .slider-prev').animate({ opacity: 1 }, 500);
	}, function(e){
		jQuery(this).find('.slider-next, .slider-prev').animate({ opacity: 0 }, 500);
		e.preventDefault();
	});
}




/*-----------------------------------------------------------------------------------*/
/*	Jcarousel
/*-----------------------------------------------------------------------------------*/
function theme_jcarousel() {

	var $carousel = jQuery('.sc-carousel ul, .related-post-lists ul');
	var $easingType= 'easeOutCubic';

	if( $carousel.length ) {

		var scrollCount;

		if( jQuery(window).width() < 480 ) {
			scrollCount = 1;
		} else if( jQuery(window).width() < 768 ) {
			scrollCount = 2;
		} else if( jQuery(window).width() < 960 ) {
			scrollCount = 3;
		} else {
			scrollCount = 4;
		}

		$carousel.jcarousel({
			animation : 600,
			easing    : $easingType,
			scroll    : scrollCount
		});
	}
}



/*-----------------------------------------------------------------------------------*/
//	Slogan Slider
/*-----------------------------------------------------------------------------------*/
function theme_slogan_slider(){
	jQuery(window).load(function() {
		jQuery('.flexslider').flexslider({
			animation: 'fade',
			slideshow: true,                
			slideshowSpeed: 6000,           
			animationDuration: 1000,         
			directionNav: true,             
			controlNav: false,              
			pausePlay: false,                                 
			controlsContainer: '.slogan-flex-container'    
		});
	});
}



/*-----------------------------------------------------------------------------------*/
//	Content Slide JS
/*-----------------------------------------------------------------------------------*/
function theme_content_slideshow(){
	if( jQuery().slides) {
	    var slider = jQuery('#post-single-slider');
		slider.slides({
	        preload: true,
			preloadImage: slider.attr('data-loader'), 
			generatePagination: true,
			generateNextPrev: true,
			paginationClass: 'slider-pagination',
			next: 'slider-next',
			prev: 'slider-prev',
			effect: 'fade',
			//play: 5000,
			//pause: 800,
			hoverPause: true,
			crossfade: false,
			autoHeight: true,
			bigTarget: false
		});
	}

	jQuery('.slider-next, .slider-prev').css('opacity','0');

	jQuery('#post-single-slider').hover(function(e){
		jQuery(this).find('.slider-next, .slider-prev').animate({ opacity: 1 }, 500);
	}, function(e){
		jQuery(this).find('.slider-next, .slider-prev').animate({ opacity: 0 }, 500);
		e.preventDefault();
	});
}



/*-----------------------------------------------------------------------------------*/
//	Go Top
/*-----------------------------------------------------------------------------------*/
function go_to_top(){
	jQuery(window).scroll(function() {
		if(jQuery(this).scrollTop() != 0) {
			jQuery('#toTop').fadeIn();	
		} else {
			jQuery('#toTop').fadeOut();
		}
	});
	jQuery('#toTop').click(function() {
		jQuery('body,html').animate({scrollTop:0},300);
	});
}



/*-----------------------------------------------------------------------------------*/
//	External links
/*-----------------------------------------------------------------------------------*/
function external_link(){
	jQuery('a[rel*=external]').click( function() {
		window.open(this.href);
		return false;
	});
}



/*-----------------------------------------------------------------------------------*/
//	prettyPhoto
/*-----------------------------------------------------------------------------------*/
function prettyPhoto(){
	jQuery("a[rel^='prettyPhoto']").prettyPhoto({
		animationSpeed:'fast',
		slideshow:3000,
		show_title:false,
		deeplinking: false,
		opacity: 0.5
	});
};


/*-----------------------------------------------------------------------------------*/
//	Portfolio List Slideshow
/*-----------------------------------------------------------------------------------*/
function portfolio_list_slideshow_nav(){
	jQuery('.slider-next, .slider-prev').css('opacity','0');
	jQuery('.post-slider-wrap').hover(function(e){
		jQuery(this).find('.slider-next, .slider-prev').animate({ opacity: 1 }, 500);
	}, function(e){
		jQuery(this).find('.slider-next, .slider-prev').animate({ opacity: 0 }, 500);
		e.preventDefault();
	});
}



/*-----------------------------------------------------------------------------------*/
/*	Top Media
/*-----------------------------------------------------------------------------------*/
function theme_top_media() {

	jQuery('.top-media li a').each(function(){
		if(jQuery(this).find('.overlay').length == 0) { 
			jQuery(this).append('<div class="overlay"></div>');
			jQuery(this).find('.overlay').css({ opacity: 0 });
		}
	});

	jQuery('.top-media li').hover(function(e){
		jQuery(this).find('.overlay').animate({ opacity: 1 }, 300);
	}, function(e){
		jQuery(this).find('.overlay').animate({ opacity: 0 }, 500);
	    e.preventDefault();
	});

}



/*-----------------------------------------------------------------------------------*/
/*	Image Hover
/*-----------------------------------------------------------------------------------*/
function theme_image_hover() {

	var hoverSpeed_Before = 300;
	var hoverSpeed_After = 500;

	jQuery('.post-thumb-hover a').each(function(){
		if(jQuery(this).find('.overlay').length == 0) { 
			jQuery(this).append('<div class="overlay"></div>');
			jQuery(this).find('.overlay').css({ opacity: 0 });
		}
	});

	jQuery('.post-thumb-hover').hover(function(e){
		jQuery(this).find('.overlay').animate({ opacity: 0.3 }, hoverSpeed_Before);
	}, function(e){
		jQuery(this).find('.overlay').animate({ opacity: 0 }, hoverSpeed_After);
	    e.preventDefault();
	});


	jQuery('.post-thumb-border a').each(function(){
		if(jQuery(this).find('.border').length == 0) { 
			jQuery(this).append('<div class="border"></div>');
			jQuery(this).find('.border').css({ opacity: 0 });
		}
	});

	jQuery('.post-thumb-border').hover(function(e){
		jQuery(this).find('.border').animate({ opacity: 1.0 }, hoverSpeed_Before);
	}, function(e){
		jQuery(this).find('.border').animate({ opacity: 0 }, hoverSpeed_After);
	    e.preventDefault();
	});
}



/*-----------------------------------------------------------------------------------*/
//	Image Preload
/*-----------------------------------------------------------------------------------*/
function theme_image_preload() {
	jQuery(window).bind('load', function() {
		 var i = 1;
		 var imgs = jQuery('.post-thumb-preload .wp-preload-image').length;
		 var int = setInterval(function() {

		 if(i >= imgs) clearInterval(int);
		 jQuery('.post-thumb-preload .wp-preload-image:not(.image-loaded)').eq(0).animate({ top: "0", opacity: "1"}, 300,"easeInQuart").addClass('image-loaded');
		 i++;
		 
		 }, 300);     
	});
}


/*-----------------------------------------------------------------------------------*/
/*	Remove Image Preload
/*-----------------------------------------------------------------------------------*/
function theme_remove_image_preload(){
	  	jQuery('.post-thumb-preload a').removeClass('image-loaded');
	  	jQuery('.wp-preload-image').css('opacity','1');
}



/*-----------------------------------------------------------------------------------*/
//	Tabbed
/*-----------------------------------------------------------------------------------*/
function theme_tabs(){
	var tabs = jQuery('ul.tabs');

	tabs.each(function(i) {

		var tab = jQuery(this).find('> li > a');
		tab.click(function(e) {

			var contentLocation = jQuery(this).attr('href');

			if(contentLocation.charAt(0)=="#") {

				e.preventDefault();

				tab.removeClass('active');
				jQuery(this).addClass('active');

				jQuery(contentLocation).show().addClass('active').siblings().hide().removeClass('active');
			}
		});
	});
}



/*-----------------------------------------------------------------------------------*/
//	Toggle
/*-----------------------------------------------------------------------------------*/
function theme_toggles(){
	jQuery("ul.toggles li").each(function(){
		jQuery(this).children(".toggle-content").css('height', function(){ 
			return jQuery(this).height(); 
		});
		jQuery(this).children(".toggle-content").not(".active").css('display','none');
		
		jQuery(this).children(".toggle-head").bind("click", function(){
			jQuery(this).children().addClass(function(){
				if(jQuery(this).hasClass("active")){
					jQuery(this).removeClass("active");
					return "";
				}
				return "active";
			});
			jQuery(this).siblings(".toggle-content").slideToggle();
		});
	});
}



/*-----------------------------------------------------------------------------------*/
//	Accordion
/*-----------------------------------------------------------------------------------*/
function theme_accordions(){
	jQuery("ul.accordions li").each(function(){
		jQuery(this).children(".accordion-content").css('height', function(){ 
			return jQuery(this).height(); 
		});
		
		if(jQuery(this).index() > 0){
			jQuery(this).children(".accordion-content").css('display','none');
		}else{
			jQuery(this).find(".accordion-head-icon").addClass('active');
		}
		
		jQuery(this).children(".accordion-head").bind("click", function(){
			jQuery(this).children().addClass(function(){
				if(jQuery(this).hasClass("active")) return "";
				return "active";
			});
			jQuery(this).siblings(".accordion-content").slideDown();
			jQuery(this).parent().siblings("li").children(".accordion-content").slideUp();
			jQuery(this).parent().siblings("li").find(".active").removeClass("active");
		});
	});
}



/*-----------------------------------------------------------------------------------*/
/*	jQuery Quicksand project categories filtering 
/*-----------------------------------------------------------------------------------*/
function theme_portfolio_quicksand(){
	var $data = jQuery(".portfolio-sortable-grid").clone();
	
	jQuery('.portfolio-sortable-menu li').click(function(e) {
		jQuery(".filter li").removeClass("active");	
		var filterClass=jQuery(this).attr('class').split(' ').slice(-1)[0];
		
		if (filterClass == 'all-items') {
			var $filteredData = $data.find('.item');
		} else {
			var $filteredData = $data.find('.item.' + filterClass );
		}
		jQuery(".portfolio-sortable-grid").quicksand($filteredData, {
			duration: 500,
			useScaling: false,
			easing: 'swing',
			adjustHeight: 'dynamic',
			enhancement: function() {
				theme_remove_image_preload();
				theme_image_hover();
				prettyPhoto();
			}		
		});
		jQuery(this).addClass("active");			
		return false;
		e.preventDefault();
	});
}



/*-----------------------------------------------------------------------------------*/
/*	Responsive 
/*-----------------------------------------------------------------------------------*/
function theme_responsive_images(){

	jQuery(".wp-caption img").each(function() { jQuery(this)
	    .removeAttr('height').removeAttr('width');	
	});

	if( jQuery(window).width() < 960 ) {

		var $allVideos = jQuery("iframe[src^='http://player.vimeo.com'], iframe[src^='http://www.youtube.com'], object, embed"),
		$fluidEl = jQuery(".video");

		$allVideos.each(function() {
		  jQuery(this)
			.attr('data-aspectRatio', this.height / this.width)
			.removeAttr('height')
			.removeAttr('width');
		});

		jQuery(window).resize(function() {
		  var newWidth = $fluidEl.width();
		  $allVideos.each(function() {
		  
			var $el = jQuery(this);
			$el
				.width(newWidth)
				.height(newWidth * $el.attr('data-aspectRatio'));
		  
		  });
		}).resize();

	}
}