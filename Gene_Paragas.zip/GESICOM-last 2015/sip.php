<?php
	$con = mysql_connect("localhost","gesicom_sip","xfO&Ng9}Tl;5");
	//$con = mysql_connect("localhost","root","");	
	if (!$con)
		{
		die('Could not connect:'.mysql_error());
		}
	mysql_select_db("gesicom_regform",$con);	
?>
<html>
<head>
<title>SIP | Registration</title>
</head>
<body>
<?php
if(isset($_POST['submit'])){
error_reporting(0);

/* Generate Quote Ticket */
function genTicketString() {
    $length = 8;
    $characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for ($p = 0; $p < $length; $p++) {
        $string .= $characters[mt_rand(0, strlen($characters)-1)];
    }
    return $string;
}
$ticket = genTicketString();

$submit_date = date('Y-m-d H:i:s');
$event = $_POST['Event'];
$fname = $_POST['FirstName'];
$lname = $_POST['LastName'];
$designation = $_POST['Designation'];
$email = $_POST['VisitorsEmail'];
$mob = $_POST['Mobile'];
$phone = $_POST['Phone'];
$company = $_POST['CompanyName'];
$add = $_POST['Address'];
$citystate = $_POST['CityState'];
$zip = $_POST['Zipcode'];
$country = $_POST['country'];
$fax = $_POST['Fax'];
$website = $_POST['Website'];
$pline = $_POST['pLine'];
$interest = implode(",",$_POST['interest']);
$companyAct = implode(",",$_POST['companyAct']);
$managementLevel = $_POST['managementLevel'];
$visitPurpose = implode(",",$_POST['visitPurpose']);
$role = implode(",",$_POST['role']);
$infoSource = implode(",",$_POST['infoSource']);

$query = mysql_query("INSERT INTO tbl_sip2013(Submitted, Event, FirstName, LastName, Designation, VisitorsEmail, Mobile, Phone, CompanyName, Address, CityState, Zipcode, country, Fax, Website, pLine, interest, companyAct, managementLevel, visitPurpose, role, infoSource, ticketNumber) VALUES('$submit_date', '$event', '$fname', '$lname', '$designation', '$email', '$mob', '$phone', '$company', '$add', '$citystate', '$zip', '$country', '$fax', '$website', '$pline', '$interest', '$companyAct', '$managementLevel', '$visitPurpose', '$role', '$infoSource', '$ticket')");

//MAIL TO VISITOR
					$to      = $email; //Send email to visitor
					//$to      = 'joanna.chan@8finity.net'; //Send email to developer for testing
					$subject = 'Pre-Registration Confirmation Number for '.$event; //// Give the email a subject 
					$message = '
	
Dear '.$fname. " " .$lname. ',  

Thank you very much for pre-registering for  '.$event.' to be held on August 15-17, 2013 at SMX Convention Center, Pasay City.

Your confirmation code is '.$ticket.'. Kindly present this code along with your business card at the registration counter during the event to claim your complimentary visitor badge.

Please do check your email regularly as we will be sending updates on what’s in store for you at this much awaited industry event. For questions, you may also reach us at tel. no. (02) 750-8588 or email info@gesi.com.ph.

We look forward to welcoming you at the show!

Sincerely,

Systems Integration Philippines
--
This mail is sent via contact form on System Integration Philippines 2013 http://gesi.com.ph/


					'; // Our message above including the link
					
					$headers = 'From: SystemIntegrationPhilippines'; // Set from headers
					mail($to, $subject, $message, $headers); // Send the email

echo '<script type="text/javascript">alert(\'YOUR PRE-REGISTRATION WAS SENT SUCCESSFULLY. YOU WILL RECEIVE AN EMAIL CONFIRMATION SHORTLY. THANK YOU.\'); window.location="sip.php"; </script>';
}else{ ?>
<form name="sip_form" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">
<style type="text/css">span.wpcf7-list-item { display: block; } 
table {width:900px !important;
font-family: "Helvetica Neue", Arial, Helvetica, sans-serif;}</style>
<div style="background:#E9E9E9; width:850px;">
<h3 align="center"><font style="font-family:Arial, Helvetica, sans-serif">Thank you for your interest in Systems Integration Philippines 2015. Pre-registration is not yet open. You may visit our Facebook page for real time updates: <br><br><a href="http://www.facebook.com/pages/Systems-Integration-Philippines-Expo">http://www.facebook.com/pages/Systems-Integration-Philippines-Expo</a></font></h3>
</div>
<p><span><input type="hidden" class="wpcf7-form-control wpcf7-text" size="40" value="Systems Integration Philippines 2013" name="Event"></span><br>
<br>
<!--Note: <font color="red">All fields are required.</font></p>
<table style="font-family:Arial, Helvetica, sans-serif; font-size:14px">
<tbody><tr>
<td colspan="2">
<h3>Personal Information</h3>
</td>
</tr>
<tr>
<td>First Name:*<br><span><input type="text" size="40" value="" name="FirstName" required /></span> </td>
<td>Last Name:*<br><span><input type="text" size="40" value="" name="LastName" required /></span></td>
</tr>
<tr>
<td>Designation:*<br><span><input type="text" size="40" value="" name="Designation" required ></span></td>
<td>Send my email confirmation to:*<br><span><input type="text" size="40" value="" name="VisitorsEmail"required ></span>
<p style="font-style:italic; font-size:0.8em; line-height:100%;">Important: Kindly make sure that you have entered the correct email <br> address in order to validate your pre-registration. Thank you.</p>
</td>
</tr>
<tr>
<td>Mobile:*<br><span><input type="text" size="40" value="" name="Mobile" required></span></td>
<td>Phone:<br><span><input type="text" size="40" value="" name="Phone"></span></td>
</tr>
<tr>
<td colspan="2">
<h3>Company Details</h3>
</td>
</tr>
<tr>
<td>Company Name:*<br><span><input type="text" size="40" value="" name="CompanyName" required></span></td>
<td>Address:*<br><span><input type="text" size="40" value="" name="Address" required></span></td>
</tr>
<tr>
<td>City/State:*<br><span><input type="text" size="40" value="" name="CityState" required></span></td>
<td>Postal/Zip Code:*<br><span><input type="text" size="40" value="" name="Zipcode" required></span></td>
</tr>
<tr>
<td>Country:*<span><select name="country"><option value="">---</option><option value="Afghanistan">Afghanistan</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Antigua &amp; Deps">Antigua &amp; Deps</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia Herzegovina">Bosnia Herzegovina</option><option value="Botswana">Botswana</option><option value="Brazil">Brazil</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina">Burkina</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Central African Rep">Central African Rep</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Congo {Democratic Rep}">Congo {Democratic Rep}</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Denmark">Denmark</option><option value="Djibouti">Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Greece">Greece</option><option value="Grenada">Grenada</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Honduras">Honduras</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Ireland {Republic}">Ireland {Republic}</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Ivory Coast">Ivory Coast</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Korea North">Korea North</option><option value="Korea South">Korea South</option><option value="Kosovo">Kosovo</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia">Malaysia</option><option value="Maldives">Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mexico">Mexico</option><option value="Micronesia">Micronesia</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar, {Burma}">Myanmar, {Burma}</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands">Netherlands</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Qatar">Qatar</option><option value="Romania">Romania</option><option value="Russian Federation">Russian Federation</option><option value="Rwanda">Rwanda</option><option value="St Kitts &amp; Nevis">St Kitts &amp; Nevis</option><option value="St Lucia">St Lucia</option><option value="Saint Vincent &amp; the Grenadines">Saint Vincent &amp; the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Sudan">South Sudan</option><option value="Spain">Spain</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tonga">Tonga</option><option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Tuvalu">Tuvalu</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City">Vatican City</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option></select></span></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>Fax:<br><span><input type="text" size="40" value="" name="Fax"></span></td>
<td>Website:<br><span><input type="text" size="40" value="" name="Website"></span></td>
</tr>
<tr>
<td>Product Line:<br><span><input type="text" class="wpcf7-form-control wpcf7-text" size="40" value="" name="pLine"></span><br><br></td>
</tr>
<tr>
<td colspan="2">
<h3>Visitor Survey</h3>
</td>
</tr>
<tr>
<td><strong>1. Industries / products / show of interest:*</strong><br>
                 <span><span><span><input type="checkbox" value="Consumer Electronics &amp; Gadgets (Digital Electronics World)" name="interest[]">&nbsp;<span class="wpcf7-list-item-label">Consumer Electronics &amp; Gadgets (Digital Electronics World)</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="1" value="Educational &amp; Training Technologies (Educa Expo)" name="interest[]">&nbsp;<span class="wpcf7-list-item-label">Educational &amp; Training Technologies (Educa Expo) </span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="2" value="Gifts &amp; Promotional Products (Corporate Gifts Expo)" name="interest[]">&nbsp;<span class="wpcf7-list-item-label">Gifts &amp; Promotional Products (Corporate Gifts Expo)</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="3" value="IT &amp; Telecoms (CommWorld)" name="interest[]">&nbsp;<span class="wpcf7-list-item-label">IT &amp; Telecoms (CommWorld)</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="4" value="Office Products &amp; Services (T.O.P.S. Show)" name="interest[]">&nbsp;<span class="wpcf7-list-item-label">Office Products &amp; Services (T.O.P.S. Show)</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="5" value="Pro Audio, Video &amp; Lighting (PALMM Philippines)" name="interest[]">&nbsp;<span class="wpcf7-list-item-label">Pro Audio, Video &amp; Lighting (PALMM Philippines)</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="6" value="Signage &amp; Multimedia (Signs &amp; Media World Expo)" name="interest[]">&nbsp;<span class="wpcf7-list-item-label">Signage &amp; Multimedia (Signs &amp; Media World Expo)</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="7" value="Systems Integration (SIP Philippines)" name="interest[]">&nbsp;<span class="wpcf7-list-item-label">Systems Integration (SIP Philippines)</span></span></span></span><br><br>
	 <strong>2. Company's main activity (choose all that apply):*</strong><br>
	        <span><span><span><input type="checkbox" value="Agent" name="companyAct[]">&nbsp;<span class="wpcf7-list-item-label">Agent</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="1" value="Buyer" name="companyAct[]">&nbsp;<span class="wpcf7-list-item-label">Buyer</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="2" value="Dealer" name="companyAct[]">&nbsp;<span class="wpcf7-list-item-label">Dealer</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="3" value="Distributor" name="companyAct[]">&nbsp;<span class="wpcf7-list-item-label">Distributor</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="4" value="Manufacturer" name="companyAct[]">&nbsp;<span class="wpcf7-list-item-label">Manufacturer</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="5" value="Retailer / Reseller" name="companyAct[]">&nbsp;<span class="wpcf7-list-item-label">Retailer / Reseller</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="6" value="Service Provider" name="companyAct[]">&nbsp;<span class="wpcf7-list-item-label">Service Provider</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="7" value="Others, please specify:" name="companyAct[]">&nbsp;<span class="wpcf7-list-item-label">Others, please specify:</span></span></span></span><span><input type="text" class="wpcf7-form-control wpcf7-text" size="40" value="" name="otherCompanyAct"></span><br><br>
	<strong>3. Management Level:*</strong><br>
	<span><span class="wpcf7-form-control wpcf7-radio"><span class="wpcf7-list-item"><input type="radio" value="Top Management" name="managementLevel">&nbsp;<span class="wpcf7-list-item-label">Top Management</span></span><span class="wpcf7-list-item"><input type="radio" tabindex="1" value="Middle Management" name="managementLevel">&nbsp;<span class="wpcf7-list-item-label">Middle Management</span></span><span class="wpcf7-list-item"><input type="radio" tabindex="2" value="Independent Professional" name="managementLevel">&nbsp;<span class="wpcf7-list-item-label">Independent Professional</span></span><span class="wpcf7-list-item"><input type="radio" tabindex="3" value="Others, please specify:" name="managementLevel">&nbsp;<span class="wpcf7-list-item-label">Others, please specify:</span></span></span></span><span><input type="text" class="wpcf7-form-control wpcf7-text" size="40" value="" name="otherManagementLevel"></span>
</td>
<td>
    <strong>4. Purpose of visit:*</strong><br>
   <span><span ><span class="wpcf7-list-item"><input type="checkbox" value="Gather information" name="visitPurpose[]">&nbsp;<span class="wpcf7-list-item-label">Gather information</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="1" value="Purchase products / equipments" name="visitPurpose[]">&nbsp;<span class="wpcf7-list-item-label">Purchase products / equipments</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="2" value="Source new product/s" name="visitPurpose[]">&nbsp;<span class="wpcf7-list-item-label">Source new product/s</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="3" value="Visit supplier / update supplier contact" name="visitPurpose[]">&nbsp;<span class="wpcf7-list-item-label">Visit supplier / update supplier contact</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="4" value="Evaluate show for future participation" name="visitPurpose[]">&nbsp;<span class="wpcf7-list-item-label">Evaluate show for future participation</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="5" value="Others, please specify:" name="visitPurpose[]">&nbsp;<span class="wpcf7-list-item-label">Others, please specify:</span></span></span></span><span><input type="text" class="wpcf7-form-control wpcf7-text" size="40" value="" name="otherVisitPurpose"></span><br><br>
<strong>5. Role in purchasing:*</strong><br>
    <span><span ><span class="wpcf7-list-item"><input type="checkbox" value="Makes purchasing decisions" name="role[]">&nbsp;<span class="wpcf7-list-item-label">Makes purchasing decisions</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="1" value="Recommends purchases" name="role[]">&nbsp;<span class="wpcf7-list-item-label">Recommends purchases</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="2" value="None" name="role[]">&nbsp;<span class="wpcf7-list-item-label">None</span></span></span></span><br><br>
<strong>6. Source of information about the event (choose all that apply):*</strong><br>
    <span><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item"><input type="checkbox" value="Print advertisement" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Print advertisement</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="1" value="Direct mail from an Organizer" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Direct mail from an Organizer</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="2" value="Direct mail from an Exhibitor" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Direct mail from an Exhibitor</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="3" value="Direct mailer from an association Please specify:" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Direct mailer from an association Please specify:</span></span></span></span><span><input type="text" class="wpcf7-form-control wpcf7-text" size="40" value="" name="specifyAssociation"></span><br>
<span><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item"><input type="checkbox" value="Billboard / Outdoor advertisements" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Billboard / Outdoor advertisements</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="1" value="Emailed invitation" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Emailed invitation</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="2" value="Website" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Website</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="3" value="TV / Radio" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">TV / Radio</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="4" value="Text / SMS info" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Text / SMS info</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="5" value="Friend / colleague" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Friend / colleague</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="6" value="Newspaper / Magazine" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Newspaper / Magazine</span></span><span class="wpcf7-list-item"><input type="checkbox" tabindex="7" value="Others, please specify:" name="infoSource[]">&nbsp;<span class="wpcf7-list-item-label">Others, please specify:</span></span></span></span><span><input type="text" class="wpcf7-form-control wpcf7-text" size="40" value="" name="otherInfoSource"></span></td>
</tr>
</tbody></table>

<input type="submit" value="Submit" name="submit">-->
<br>
<span><input type="hidden" size="40" class="wpcf7-text" value="DPH0HA3T" name="ticket"></span></p>
<div class="wpcf7-response-output wpcf7-display-none"></div>
</form>
<?php } ?>
</body>
</html>
