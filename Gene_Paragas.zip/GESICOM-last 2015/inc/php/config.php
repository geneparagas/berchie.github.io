<?php




//connect to the database

mysql_connect('localhost', 'gesicom_sip', 'xfO&Ng9}Tl;5') or die("I couldn't connect to your database, please make sure your info is correct!");

mysql_select_db('gesicom_regform') or die("I couldn't find the database table ($table) make sure it's spell right!");


?>