// JavaScript Document
$("#del01,#amount01").keyup(function() {
    var a = parseInt(document.getElementById('del01').value);
	var b =  a  + 1800;
    
    document.getElementById('amount').value = b;
    
     });