<!doctype html>

<!--Begin Html-->
<html dir="ltr" lang="en-US">

<!--Begin Head-->
<head>

<!--Meta Tags-->
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />

<title>Global-Link Exhibitions Specialist, Inc.</title>


<link rel='stylesheet' id='contact-form-7-css'  href='css/style2.css' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='css/style.css' type='text/css' media='screen' />
<link rel='stylesheet' id='slideshow-css'  href='css/slideshow.css' type='text/css' media='screen' />
<link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css' type='text/css' media='screen' />
<link rel='stylesheet' id='shortcodes-css'  href='css/shortcodes.css' type='text/css' media='screen' />
<link rel='stylesheet' id='widgets-css'  href='css/widgets.css' type='text/css' media='screen' />
<link rel='stylesheet' id='prettyphoto-css'  href='css/prettyphoto.css' type='text/css' media='screen' />
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery.scripts.js'></script>
<script type='text/javascript' src='js/html5.min.js'></script>
<script type='text/javascript' src='js/custom.js'></script>
   <script src="script.js"></script>
   <link rel="stylesheet" href="styles.css">

<!--Extend CSS-->
<style type="text/css">

	#slides-wrap-home .slider-pagination { left: 400px; }
		.site-logo, .site-name { margin-top: 0px; margin-bottom: 0px; }
		.top-media { margin-top: 45px; }
		.ddsmoothmenu ul li ul li a { width: 160px; }
		body { font-family: "Helvetica Neue", Arial, Helvetica, sans-serif; }
		nav { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		h1, h2, h3, h4, h5, h6 { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		.meta { font-family: "Mako", Helvetica, Arial, serif, sans-serif; }
		#top-menu ul.drop-menu li a { font-size: 14px; font-weight:bold; }
		#top-menu ul.drop-menu li ul li a { font-size: 12px; }
		.post-content h1  { font-size: 24px; }
		.post-content h2  { font-size: 20px; }
		.post-content h3  { font-size: 16px; }
		.post-content h4  { font-size: 14px; }
		.post-content h5  { font-size: 12px; }
		.post-content h6  { font-size: 10px; }
		body { color: #666666; }
		a { color: #333333; }
		a:hover,
		#top-menu ul.drop-menu li a:hover,
		#top-menu ul.drop-menu li a.selected,
		#top-menu ul.drop-menu li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-item a,
		#top-menu ul.drop-menu li.current_page_parent a,
		#top-menu ul.drop-menu li.current-menu-parent a,
		.blog-list li .post-meta a:hover,
		.post-blog-single .post-meta a:hover,
		.comment-meta .fn a:hover,
		.comment-form-author span,
		.comment-form-email span,
		.widget-tweets li .date a:hover,
		.widget-posts li .post-meta a:hover,
		.widget-portfolios li .post-meta a:hover,
		.sc-slider-list li .meta a:hover,
		.sc-slider-list li .skills a:hover,
		.home-service-box .title,
		.commentlist li .reply:hover,
		.sc-pricing-table-wrap .pricing-item .price-currency { color: #f56622; }
		.post-more a:hover,
		.blog-list li .more-link:hover,
		.post-portfolio-single .single-post-pagenation li a:hover,
		.comment-form-author input[type="text"]:focus,
		.comment-form-email input[type="text"]:focus,
		.comment-form-url input[type="text"]:focus,
		#commentform .comment-form-comment:focus,
		#commentform .form-submit input[type="submit"]:hover,
		.wp-pagenavi a:hover, 
		.wp-pagenavi span.current,
		.pagination a:hover,
		.pagination span.current,
		.normal-pagination span a:hover,
		.comment-pagination a:hover, 
		.comment-pagination span.current,
		.sortable-menu li.current-cat a,
		.sortable-menu li.active a,
		.sortable-menu li a:hover,
		.post-single-contact .input-block input:focus,
		.post-single-contact .textarea-block #contact-message:focus,
		.post-single-contact .submit-block input[type="submit"]:hover,
		.jcarousel-prev:hover, .jcarousel-prev:focus, .jcarousel-prev:active,
		.jcarousel-next:hover, .jcarousel-next:focus, .jcarousel-next:active,
		.sc-tabs-wrap .tabs li .active,
		.sc-pricing-table-wrap .pricing-item .button-wrap a:hover { background-color: #4e2350; }
		.jcarousel-prev-disabled, .jcarousel-prev-disabled:hover,
		.jcarousel-prev-disabled:focus, .jcarousel-prev-disabled:active,
		.jcarousel-next-disabled, .jcarousel-next-disabled:hover,
		.jcarousel-next-disabled:focus, .jcarousel-next-disabled:active { background-color: #EEE; }
		.post-thumb-border .border { border: 5px solid #4e2350; }

		#top-menu ul.drop-menu li.current_page_parent ul li a,
		#top-menu ul.drop-menu li.current-menu-parent ul li a { color: #333; }

		#top-menu ul.drop-menu li.current_page_parent ul li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-parent ul li.current-menu-item a { color: #fff; }
		

			body { background: url(images/bg_new1.jpg) no-repeat center center fixed #161616; -webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover; } 

.details{ margin:15px 20px; }			
h4{ font:300 16px 'Helvetica Neue', Helvetica, Arial, sans-serif; line-height:140%; color:#fff; text-shadow:1px 1px 0 rgb(0,0,0); }
					p{ font:300 12px 'Lucida Grande', Tahoma, Verdana, sans-serif; color:#aaa; text-shadow:none;}
					a{ text-decoration:none; }			
			
</style>

		<!--Custom CSS-->
		
		<link type="text/css" rel="stylesheet" href="css/custom.css" media="screen" />
		<link href='css/css2.css' rel='stylesheet' type='text/css'>
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="shortcut icon" href="images/fav-iffina.png" />

<!--End head-->


<link rel="stylesheet" href="css/bsa.css" type="text/css" media="screen" /> 
		<link rel="stylesheet" href="css/mosaic.css" type="text/css" media="screen" />
		<script type="text/javascript" src="js/jquery.min.js"></script>		
		<script type="text/javascript" src="js/mosaic.1.0.1.min.js"></script>
		
		<script type="text/javascript">  
			
			$(document).ready(function($){
				
				$('.circle').mosaic({
					opacity		:	0.8			//Opacity for overlay (0-1)
				});
				
				$('.fade').mosaic();
				
				$('.bar').mosaic({
					animation	:	'slide'		//fade or slide
				});
				
				$('.bar2').mosaic({
					animation	:	'slide'		//fade or slide
				});
				
				$('.bar3').mosaic({
					animation	:	'slide',	//fade or slide
					anchor_y	:	'top'		//Vertical anchor position
				});
				
				$('.cover').mosaic({
					animation	:	'slide',	//fade or slide
					hover_x		:	'400px'		//Horizontal position on hover
				});
				
				$('.cover2').mosaic({
					animation	:	'slide',	//fade or slide
					anchor_y	:	'top',		//Vertical anchor position
					hover_y		:	'80px'		//Vertical position on hover
				});
				
				$('.cover3').mosaic({
					animation	:	'slide',	//fade or slide
					hover_x		:	'400px',	//Horizontal position on hover
					hover_y		:	'300px'		//Vertical position on hover
				});

		    
		    });
		    
		</script>
		

</head>

<!--Begin Body-->
<body class="home page page-id-369 page-template page-template-template-home-php wp-front-page">

<div id="page" class="hfeed">

<!--Begin Header-->
<header id="site-head">
	<div class="clearfix col-box">
	<div class="site-logo">
<a href="index.html"><img src="images/GMP_Logo.png" width="287" height="117" /></a>
</div>
<div class="site-logo2">
<a href="http://www.globallinkmp.com/pre-registration-page/" target="_blank"><img src="images/pre-reg.png" width="300" height="45"></a><br><img src="images/proposal.png" width="300" height="45">
      </div>
	</div><!--End Header-->
</header>
<div id='cssmenu'>

<ul><li><a href="index.html">HOME</a></li>
<li><a href="shows.php">EVENTS</a>
</li>
<li><a href="services.php">SERVICES</a>
</li>
<li><a href="#">PORTFOLIO</a>
</li>
<li><a href="#">NEWS</a>
</li>
<li class='active'><a href="about_us.php">ABOUT US</a></li>
<!--<li id="menu-item-596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-596"><a href="feature.html">SPECIAL FEATURE</a></li>-->

<li><a href="contacts.php">CONTACT US</a></li>
</ul></div>
</div>
<div id="page" class="hfeed"><div id="main" class="fullwidth">

<!--Begin Content-->
<article id="content"><img src="images/landing_banner.jpg" width="990" height="166"><!--end slides-wrap-->
<div class="col-box home-service-box clearfix"><div class="col-1-4 col-first clearfix"><h1 class="title"><br>OUR MISSION</h1>

<table width="300" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2">
As a trade event organizer, our primary aim is to create a venue for sellers to meet their target buyers. The solutions we offer are diverse enough to be dynamic and yet focused enough to meet the specific needs of our clients. Our events help companies maximize their business potentials while allowing buyers to get the most out of the trade opportunities.


</td>
    </tr>
  
</table>
<h1 class="title"><br>THE GLOBAL-LINK ADVANTAGE</h1>

<table width="300" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2">
The company’s core management has been immersed in various exhibitions and related industries from as far back as 1990. When you work with Global-Link MP, you can be assured that you are dealing with people who know the business from every possible angle. As a whole, the team prides itself with:<br>

&bull;&nbsp;A good track record and reputation in organizing successful exhibitions and events<br>
&bull;&nbsp;A diverse portfolio of events encompassing various sectors / industries<br>
&bull;&nbsp;Over 500,000 database of its own – updated regularly – in almost every major industry<br>
&bull;&nbsp;Being a one-stop shop for event organizing<br>
&bull;&nbsp;A solid and reliable pool of industry suppliers<br>
&bull;&nbsp;A membership to the World Events Organization (WEO) as well as affiliation with the MP Group of Singapore and Pico Far East Holdings Group<br>
&bull;&nbsp;A good working relationship with regional, national, and local media<br>
&bull;&nbsp;A strong government and private sector network and relationship
 


</td>
    </tr>
  
</table>

</div></div><br><br><br>
</article>
<!--End Content-->


<!-- #main -->
<footer>

<!--Begin Footer Widget--><!--End Footer Widget-->

<div class="footer-message">

Copyright &copy; - GLOBAL-LINK EXHIBITIONS SPECIALIST, INC. - MIS.
</div>
<!--end # footer message-->
<!--End Footer-->
</footer>
<!-- # page -->
</div></div>
<div id="toTop">Back to top</div>


	<div style="display:none">
	</div>
<script type="text/javascript">
//<![CDATA[
ddsmoothmenu.init({
mainmenuid: "top-menu", 
orientation: "h", 
classname: "ddsmoothmenu", 
contentsource: "markup" 
});
//]]>
</script>

<script type='text/javascript' src='js/jquery.form.js'></script>



<script src="js/e-201319.js" type="text/javascript"></script>
	<script type="text/javascript">
	st_go({v:'ext',j:'1:1.4.2',blog:'38302682',post:'369'});
	var load_cmc = function(){linktracker_init(38302682,369,2);};
	if ( typeof addLoadEvent != 'undefined' ) addLoadEvent(load_cmc);
	else load_cmc();
	</script><!--End Body-->
</body>

<!--End Html-->
</html>