<!doctype html>

<!--Begin Html-->
<html dir="ltr" lang="en-US">

<!--Begin Head-->
<head>

<!--Meta Tags-->
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />

<title>Global-Link Exhibitions Specialist, Inc.</title>


<link rel='stylesheet' id='contact-form-7-css'  href='css/style2.css' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='css/style.css' type='text/css' media='screen' />
<link rel='stylesheet' id='slideshow-css'  href='css/slideshow.css' type='text/css' media='screen' />
<link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css' type='text/css' media='screen' />
<link rel='stylesheet' id='shortcodes-css'  href='css/shortcodes.css' type='text/css' media='screen' />
<link rel='stylesheet' id='widgets-css'  href='css/widgets.css' type='text/css' media='screen' />
<link rel='stylesheet' id='prettyphoto-css'  href='css/prettyphoto.css' type='text/css' media='screen' />
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery.scripts.js'></script>
<script type='text/javascript' src='js/html5.min.js'></script>
<script type='text/javascript' src='js/custom.js'></script>
   <script src="script.js"></script>
   <link rel="stylesheet" href="styles.css">

<!--Extend CSS-->
<style type="text/css">

	#slides-wrap-home .slider-pagination { left: 400px; }
		.site-logo, .site-name { margin-top: 0px; margin-bottom: 0px; }
		.top-media { margin-top: 45px; }
		.ddsmoothmenu ul li ul li a { width: 160px; }
		body { font-family: "Helvetica Neue", Arial, Helvetica, sans-serif; }
		nav { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		h1, h2, h3, h4, h5, h6 { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		.meta { font-family: "Mako", Helvetica, Arial, serif, sans-serif; }
		#top-menu ul.drop-menu li a { font-size: 14px; font-weight:bold; }
		#top-menu ul.drop-menu li ul li a { font-size: 12px; }
		.post-content h1  { font-size: 24px; }
		.post-content h2  { font-size: 20px; }
		.post-content h3  { font-size: 16px; }
		.post-content h4  { font-size: 14px; }
		.post-content h5  { font-size: 12px; }
		.post-content h6  { font-size: 10px; }
		body { color: #666666; }
		a { color: #333333; }
		a:hover,
		#top-menu ul.drop-menu li a:hover,
		#top-menu ul.drop-menu li a.selected,
		#top-menu ul.drop-menu li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-item a,
		#top-menu ul.drop-menu li.current_page_parent a,
		#top-menu ul.drop-menu li.current-menu-parent a,
		.blog-list li .post-meta a:hover,
		.post-blog-single .post-meta a:hover,
		.comment-meta .fn a:hover,
		.comment-form-author span,
		.comment-form-email span,
		.widget-tweets li .date a:hover,
		.widget-posts li .post-meta a:hover,
		.widget-portfolios li .post-meta a:hover,
		.sc-slider-list li .meta a:hover,
		.sc-slider-list li .skills a:hover,
		.home-service-box .title,
		.commentlist li .reply:hover,
		.sc-pricing-table-wrap .pricing-item .price-currency { color: #f56622; }
		.post-more a:hover,
		.blog-list li .more-link:hover,
		.post-portfolio-single .single-post-pagenation li a:hover,
		.comment-form-author input[type="text"]:focus,
		.comment-form-email input[type="text"]:focus,
		.comment-form-url input[type="text"]:focus,
		#commentform .comment-form-comment:focus,
		#commentform .form-submit input[type="submit"]:hover,
		.wp-pagenavi a:hover, 
		.wp-pagenavi span.current,
		.pagination a:hover,
		.pagination span.current,
		.normal-pagination span a:hover,
		.comment-pagination a:hover, 
		.comment-pagination span.current,
		.sortable-menu li.current-cat a,
		.sortable-menu li.active a,
		.sortable-menu li a:hover,
		.post-single-contact .input-block input:focus,
		.post-single-contact .textarea-block #contact-message:focus,
		.post-single-contact .submit-block input[type="submit"]:hover,
		.jcarousel-prev:hover, .jcarousel-prev:focus, .jcarousel-prev:active,
		.jcarousel-next:hover, .jcarousel-next:focus, .jcarousel-next:active,
		.sc-tabs-wrap .tabs li .active,
		.sc-pricing-table-wrap .pricing-item .button-wrap a:hover { background-color: #4e2350; }
		.jcarousel-prev-disabled, .jcarousel-prev-disabled:hover,
		.jcarousel-prev-disabled:focus, .jcarousel-prev-disabled:active,
		.jcarousel-next-disabled, .jcarousel-next-disabled:hover,
		.jcarousel-next-disabled:focus, .jcarousel-next-disabled:active { background-color: #EEE; }
		.post-thumb-border .border { border: 5px solid #4e2350; }

		#top-menu ul.drop-menu li.current_page_parent ul li a,
		#top-menu ul.drop-menu li.current-menu-parent ul li a { color: #333; }

		#top-menu ul.drop-menu li.current_page_parent ul li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-parent ul li.current-menu-item a { color: #fff; }
		

			body { background: url(images/bg_new1.jpg) no-repeat center center fixed #161616; -webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover; } 

.details{ margin:15px 20px; }			
h4{ font:300 16px 'Helvetica Neue', Helvetica, Arial, sans-serif; line-height:140%; color:#fff; text-shadow:1px 1px 0 rgb(0,0,0); }
					p{ font:300 12px 'Lucida Grande', Tahoma, Verdana, sans-serif; color:#aaa; text-shadow:none;}
					a{ text-decoration:none; }			
			
</style>

		<!--Custom CSS-->
		
		<link type="text/css" rel="stylesheet" href="css/custom.css" media="screen" />
		<link href='css/css2.css' rel='stylesheet' type='text/css'>
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="shortcut icon" href="images/fav-iffina.png" />

<!--End head-->


<link rel="stylesheet" href="css/bsa.css" type="text/css" media="screen" /> 

		<script type="text/javascript" src="js/jquery.min.js"></script>		
		
<link rel="stylesheet" href="jqtransformplugin/jqtransform.css" type="text/css" media="all" />
	<script type="text/javascript" src="requiered/jquery.js" ></script>
	<script type="text/javascript" src="jqtransformplugin/jquery.jqtransform.js" ></script>
	<script language="javascript">
		$(function(){
			$('form').jqTransform({imgPath:'jqtransformplugin/img/'});
		});
	</script>
    <script>
function processData(f1,f2,f3,f4,f5,f6){
	var v1 = document.getElementById(f1).value;
	var v2 = document.getElementById(f2).value;
	var v3 = document.getElementById(f3).value;
	var v4 = document.getElementById(f4).value;
	var v5 = document.getElementById(f5).value;
	var v6 = document.getElementById(f6).value;
	alert(v1+"\n"+v2+"\n"+v3+"\n"+v4+"\n"+v5+"\n"+v6);
	// Use Ajax-PHP to send the values to server storage
	// Ajax-PHP Video Tutorial - www.developphp.com/view.php?tid=1185
}
</script>
</head>

<!--Begin Body-->
<body class="home page page-id-369 page-template page-template-template-home-php wp-front-page">

<div id="page" class="hfeed">

<!--Begin Header-->
<header id="site-head">
	<div class="clearfix col-box">
	<div class="site-logo">
<a href="index.html"><img src="images/GMP_Logo.png" width="287" height="117" /></a>
</div>
<div class="site-logo2">
<a href="http://www.globallinkmp.com/pre-registration-page/" target="_blank"><img src="images/pre-reg.png" width="300" height="45"></a><br><img src="images/proposal.png" width="300" height="45">
      </div>
	</div><!--End Header-->
</header>
<div id='cssmenu'>

<ul><li><a href="index.html">HOME</a></li>
<li><a href="shows.php">EVENTS</a>
</li>
<li><a href="services.php">SERVICES</a>
</li>
<li><a href="#">PORTFOLIO</a>
</li>
<li><a href="#">NEWS</a>
</li>
<li><a href="about_us.php">ABOUT US</a></li>
<!--<li id="menu-item-596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-596"><a href="feature.html">SPECIAL FEATURE</a></li>-->

<li><a href="contacts.php">CONTACT US</a></li>
</ul></div>
</div>
<div id="page" class="hfeed"><div id="main" class="fullwidth">

<!--Begin Content-->
<article id="content"><img src="images/landing_banner.jpg" width="990" height="166"><!--end slides-wrap-->
<div class="col-box home-service-box clearfix"><div class="col-1-4 col-first clearfix"><div class="container">  
      <div  class="form">
      

  		
	<form name="digi_form" method="post"  enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>">
    <table width="890" class="font3">
<tbody>
<tr>

<td height="95" colspan="4" align="left"><p><span><input type="hidden" class="wpcf7-form-control wpcf7-text" size="40" value="Gesicom" name="Event"></span><br><font style="color:#FF6600; font-size:30px"><b>REQUEST FOR PROPOSAL</b></font><br>
</p></td>
<td colspan="2" align="center">&nbsp;</td>
</tr>
<tr>
<td height="69" colspan="4">First Name: <font color="#FF0000">*</font> <br />
  <input type="text" size="30" value="" name="FirstName" required /></td>
<td colspan="2" align="left">Last name : <font color="#FF0000">*</font><br /><span><input type="text" size="30" value="" name="LastName"  required /></span></td>
</tr>
<tr>
<td colspan="4" height="69" valign="top">Company Name: <font color="#FF0000">*</font><br />
  <span>
    <input type="text" size="30" value="" name="CompanyName"  required /></span></td>
<td colspan="2" align="left">Job Title / Designation:<font color="#FF0000">*</font><br />
  <span>
    <input type="text" size="30" value="" name="Designation" tooltiptext="Type your Website in this box" />
  </span></td>


</tr>
<tr>
<td colspan="3" height="69">Company Address: <font style="font-size:12px"><i>(Building name, Street Address and Barangay, etc.):</i></font><font color="#FF0000">*</font><br />
  <span>
    <textarea name="Address" cols="40" tooltiptext="Type your Address in this box" required minlength="20"></textarea>
  </span></td>
<td height="69">&nbsp;</td>
<td width="374" height="69"></td>
<td width="88" height="69">&nbsp;</td>
</tr>
<tr>
  <td height="69" colspan="4">City/State:<font color="#FF0000">*</font><br />
    <span>
      <input type="text" size="30" value="" name="CityState" tooltiptext="Type your City/State in this box" /></span></td>
  <td colspan="2" align="left">Postal/Zip Code:<font color="#FF0000">*</font><br />
  <span>
    <input type="text" size="30" value="" name="Zipcode" tooltiptext="Type your Zip Code in this box" />
  </span></td>
 
</tr>
<tr>
<td height="69" colspan="4" align="left">Country:<font color="#FF0000">*</font><br />
  <span>
    <select name="country"  ><option value="Philippines">Philippines</option>
      <option value="Afghanistan">Afghanistan</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Antigua &amp; Deps">Antigua &amp; Deps</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia Herzegovina">Bosnia Herzegovina</option><option value="Botswana">Botswana</option><option value="Brazil">Brazil</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina">Burkina</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Central African Rep">Central African Rep</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Congo {Democratic Rep}">Congo {Democratic Rep}</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Denmark">Denmark</option><option value="Djibouti">Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Greece">Greece</option><option value="Grenada">Grenada</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Honduras">Honduras</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Ireland {Republic}">Ireland {Republic}</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Ivory Coast">Ivory Coast</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Korea North">Korea North</option><option value="Korea South">Korea South</option><option value="Kosovo">Kosovo</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia">Malaysia</option><option value="Maldives">Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mexico">Mexico</option><option value="Micronesia">Micronesia</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar, {Burma}">Myanmar, {Burma}</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands">Netherlands</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Qatar">Qatar</option><option value="Romania">Romania</option><option value="Russian Federation">Russian Federation</option><option value="Rwanda">Rwanda</option><option value="St Kitts &amp; Nevis">St Kitts &amp; Nevis</option><option value="St Lucia">St Lucia</option><option value="Saint Vincent &amp; the Grenadines">Saint Vincent &amp; the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Sudan">South Sudan</option><option value="Spain">Spain</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tonga">Tonga</option><option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Tuvalu">Tuvalu</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City">Vatican City</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option>
      </select>
  </span></td>
<td colspan="2" align="center">&nbsp;</td>

</tr>
<tr>
	<td colspan="4" align="left" valign="top"></td>
    <td colspan="2" align="left"></td>

</tr>
<tr>
<td height="69" colspan="4">Tel No: <font color="#FF0000">*</font> <br />
  <input type="text" size="30" value="" name="Phone" tooltiptext="Type your Phone # in this box" required /></td>
<td colspan="2" align="left">Fax No:<font color="#FF0000">*</font><br />
  <span>
    <input type="text" size="30" value="" name="Fax" tooltiptext="Type your Fax # in this box" />
  </span></td>
</tr>
<tr>
<td height="69" colspan="4">Email Address 1:<font color="#FF0000">*</font> <br />
  <input type="text" size="30" value="" name="VisitorsEmail" required /></font></td>
<td colspan="2" align="left"></td>
</tr>
<tr>
<td height="69" colspan="4">Email Address 2:<font color="#FF0000">*</font> <br />
  <input type="text" size="30" value="" name="Emailb" required /></font></td>
  <td colspan="2" rowspan="2" align="left">&nbsp;</td>
  </tr>
<tr>
  <td height="69" colspan="4">TYPE OF PROJECT:<font color="#FF0000">*</font><br />
  <span>
    <select name="Projects"  ><option value="Agency Representation">Agency Representation</option>
      <option value="Below-the-Line Marketing">Below-the-Line Marketing</option><option value="Booth Design / Construction">Booth Design / Construction</option><option value="Brand Activation">Brand Activation</option><option value="Business-To-Business Matching">Business-To-Business Matching</option><option value="Conference Management">Conference Management</option><option value="Corporate & Special Events">Corporate & Special Events</option><option value="Database Generation / Management">Database Generation / Management</option>
      <option value="Event Management">Event Management</option><option value="Exhibit Organizing">Exhibit Organizing</option><option value="Publicity And Advertising">Publicity And Advertising</option><option value="Registration Handling">Registration Handling</option><option value="Road Show Management">Road Show Management</option>
      <option value="Stage Design And Management">Stage Design And Management</option>
      <option value="Telemarketing / Call Center Services">Telemarketing / Call Center Services</option>
      <option value="Trade Missions">Trade Missions</option>
      <option value="Visitor Promotions">Visitor Promotions</option>
      </select>
  </span></td>
</tr>
<tr>
  <td height="86" colspan="3">Brief Description<font color="#FF0000">*</font><br />
    <span>
      <textarea name="Description" cols="40"  required></textarea>
    </span></td>
  <td height="86">&nbsp;</td>
  <td colspan="2" align="left">&nbsp;</td>
</tr>
<tr>
  <td height="69" colspan="4">Target Date: <font color="#FF0000">*</font> <br />
	  <input type="date"  value="" name="Date" size="30" /></td>
  <td colspan="2" align="left">&nbsp;</td>
</tr>
<tr>
  <td height="69" colspan="4">Venue: <font color="#FF0000">*</font> <br />
	  <input type="text" size="30" value="" name="Venue" required /></td>
  <td colspan="2" align="left">&nbsp;</td>
</tr>

<tr>
  <td height="84" colspan="6">UPLOAD SUPPORTING DOCUMENT (optional) <br /><input type="file" name="file" /><br>(Supports PDF, Docx and Doc. Maximum File Size: 2MB)</td>
  </tr>
<tr>
  <td height="79"><input type="checkbox"  required /></td>
  <td height="79" colspan="6" align="justify">By checking this box, I hereby agree and understand that the contact information provided will be used by Global-Link to process my enquiry and that I shall be approached by a designated team to proceed with any actions relating to my request and the nature of my enquiry.</td>
  </tr>
<tr>
  <td height="107"><input type="checkbox" value="" required /></td>
  <td height="107" colspan="5" align="justify">By checking this box I hereby agree and understand that the contact information provided will be used by Global-Link to send me information on products and services and marketing messages, and to ascertain if I am interested in any proposals which Global-Link considers appropriate or useful to me, including, but not limited to, branding, exhibits, events, interior fit-out and other marketing activities. I understand that I may unsubscribe or opt not to receive these messages at any time by writing to info@gesi.com.ph</td>
</tr>
<tr>
  <td height="20"><input type="checkbox" value="" required /></td>
  <td height="20" colspan="5">I have read and accept the <a href="#">Terms of Use and Personal Data Policy</a></td>
  </tr>
<tr>
  <td width="27" height="21">&nbsp;</td>
  <td width="79">&nbsp;</td>
  <td height="21">&nbsp;</td>
  <td height="21">&nbsp;</td>
  <td colspan="2" align="left">&nbsp;</td>
</tr>
    <tr>
                        <td colspan="4"><strong>Kindly fill up the captcha below before clicking submit button.</strong> <font color="red">*</font></td>
                        <td  align="left">&nbsp;</td>
                        <td  align="left">&nbsp;</td>
                        
                  </tr>
                    <tr>
                        <td height="71" colspan="2" valign="top"><input type="text" name="captcha" id="captcha" maxlength="6" size="10"/></td>
                        <td width="287" valign="top"><img width="70" height="30" src="captcha.php"/></td>
                        <td width="57" rowspan="2"  align="left"></td>
                        <td rowspan="2"  align="left">&nbsp;</td>
                        <td  rowspan="2" align="left">&nbsp;</td>
                        
                    </tr>
                    <tr>
                      <td height="28" colspan="3" valign="top"><span class="rowElem">
                      <input type="submit" name="submit" value="Submit" /></span>	</td>
                    </tr>
  </table>
		
</form>

    
</div></div>
</div></div><br><br><br>
</article>

<!--End Content-->


<!-- #main -->
<footer>

<!--Begin Footer Widget--><!--End Footer Widget-->

<div class="footer-message">

Copyright &copy; - GLOBAL-LINK EXHIBITIONS SPECIALIST, INC. - MIS.
</div>
<!--end # footer message-->
<!--End Footer-->
</footer>
<!-- # page -->
</div></div>
<div id="toTop">Back to top</div>


	<div style="display:none">
	</div>
<script type="text/javascript">
//<![CDATA[
ddsmoothmenu.init({
mainmenuid: "top-menu", 
orientation: "h", 
classname: "ddsmoothmenu", 
contentsource: "markup" 
});
//]]>
</script>

<script type='text/javascript' src='js/jquery.form.js'></script>

<br>

<!--End Body-->
</body>

<!--End Html-->
</html>