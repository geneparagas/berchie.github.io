<!doctype html>

<!--Begin Html-->
<html dir="ltr" lang="en-US">

<!--Begin Head-->
<head>

<!--Meta Tags-->
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />

<title>Global-Link Exhibitions Specialist, Inc.</title>


<link rel='stylesheet' id='contact-form-7-css'  href='css/style2.css' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='css/style.css' type='text/css' media='screen' />
<link rel='stylesheet' id='slideshow-css'  href='css/slideshow.css' type='text/css' media='screen' />
<link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css' type='text/css' media='screen' />
<link rel='stylesheet' id='shortcodes-css'  href='css/shortcodes.css' type='text/css' media='screen' />
<link rel='stylesheet' id='widgets-css'  href='css/widgets.css' type='text/css' media='screen' />
<link rel='stylesheet' id='prettyphoto-css'  href='css/prettyphoto.css' type='text/css' media='screen' />
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery.scripts.js'></script>
<script type='text/javascript' src='js/html5.min.js'></script>
<script type='text/javascript' src='js/custom.js'></script>
   <script src="script.js"></script>
   <link rel="stylesheet" href="styles.css">

<!--Extend CSS-->
<style type="text/css">

	#slides-wrap-home .slider-pagination { left: 400px; }
		.site-logo, .site-name { margin-top: 0px; margin-bottom: 0px; }
		.top-media { margin-top: 45px; }
		.ddsmoothmenu ul li ul li a { width: 160px; }
		body { font-family: "Helvetica Neue", Arial, Helvetica, sans-serif; }
		nav { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		h1, h2, h3, h4, h5, h6 { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		.meta { font-family: "Mako", Helvetica, Arial, serif, sans-serif; }
		#top-menu ul.drop-menu li a { font-size: 14px; font-weight:bold; }
		#top-menu ul.drop-menu li ul li a { font-size: 12px; }
		.post-content h1  { font-size: 24px; }
		.post-content h2  { font-size: 20px; }
		.post-content h3  { font-size: 16px; }
		.post-content h4  { font-size: 14px; }
		.post-content h5  { font-size: 12px; }
		.post-content h6  { font-size: 10px; }
		body { color: #666666; }
		a { color: #333333; }
		a:hover,
		#top-menu ul.drop-menu li a:hover,
		#top-menu ul.drop-menu li a.selected,
		#top-menu ul.drop-menu li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-item a,
		#top-menu ul.drop-menu li.current_page_parent a,
		#top-menu ul.drop-menu li.current-menu-parent a,
		.blog-list li .post-meta a:hover,
		.post-blog-single .post-meta a:hover,
		.comment-meta .fn a:hover,
		.comment-form-author span,
		.comment-form-email span,
		.widget-tweets li .date a:hover,
		.widget-posts li .post-meta a:hover,
		.widget-portfolios li .post-meta a:hover,
		.sc-slider-list li .meta a:hover,
		.sc-slider-list li .skills a:hover,
		.home-service-box .title,
		.commentlist li .reply:hover,
		.sc-pricing-table-wrap .pricing-item .price-currency { color: #f56622; }
		.post-more a:hover,
		.blog-list li .more-link:hover,
		.post-portfolio-single .single-post-pagenation li a:hover,
		.comment-form-author input[type="text"]:focus,
		.comment-form-email input[type="text"]:focus,
		.comment-form-url input[type="text"]:focus,
		#commentform .comment-form-comment:focus,
		#commentform .form-submit input[type="submit"]:hover,
		.wp-pagenavi a:hover, 
		.wp-pagenavi span.current,
		.pagination a:hover,
		.pagination span.current,
		.normal-pagination span a:hover,
		.comment-pagination a:hover, 
		.comment-pagination span.current,
		.sortable-menu li.current-cat a,
		.sortable-menu li.active a,
		.sortable-menu li a:hover,
		.post-single-contact .input-block input:focus,
		.post-single-contact .textarea-block #contact-message:focus,
		.post-single-contact .submit-block input[type="submit"]:hover,
		.jcarousel-prev:hover, .jcarousel-prev:focus, .jcarousel-prev:active,
		.jcarousel-next:hover, .jcarousel-next:focus, .jcarousel-next:active,
		.sc-tabs-wrap .tabs li .active,
		.sc-pricing-table-wrap .pricing-item .button-wrap a:hover { background-color: #4e2350; }
		.jcarousel-prev-disabled, .jcarousel-prev-disabled:hover,
		.jcarousel-prev-disabled:focus, .jcarousel-prev-disabled:active,
		.jcarousel-next-disabled, .jcarousel-next-disabled:hover,
		.jcarousel-next-disabled:focus, .jcarousel-next-disabled:active { background-color: #EEE; }
		.post-thumb-border .border { border: 5px solid #4e2350; }

		#top-menu ul.drop-menu li.current_page_parent ul li a,
		#top-menu ul.drop-menu li.current-menu-parent ul li a { color: #333; }

		#top-menu ul.drop-menu li.current_page_parent ul li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-parent ul li.current-menu-item a { color: #fff; }
		

			body { background: url(images/bg_new1.jpg) no-repeat center center fixed #161616; -webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover; } 

.details{ margin:15px 20px; }			
h4{ font:300 16px 'Helvetica Neue', Helvetica, Arial, sans-serif; line-height:140%; color:#fff; text-shadow:1px 1px 0 rgb(0,0,0); }
					p{ font:300 12px 'Lucida Grande', Tahoma, Verdana, sans-serif; color:#aaa; text-shadow:none;}
					a{ text-decoration:none; }			
			
</style>

		<!--Custom CSS-->
		
		<link type="text/css" rel="stylesheet" href="css/custom.css" media="screen" />
		<link href='css/css2.css' rel='stylesheet' type='text/css'>
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="shortcut icon" href="images/fav-iffina.png" />

<!--End head-->


<link rel="stylesheet" href="css/bsa.css" type="text/css" media="screen" /> 
		<link rel="stylesheet" href="css/mosaic.css" type="text/css" media="screen" />
		<script type="text/javascript" src="js/jquery.min.js"></script>		
		<script type="text/javascript" src="js/mosaic.1.0.1.min.js"></script>
		
		<script type="text/javascript">  
			
			$(document).ready(function($){
				
				$('.circle').mosaic({
					opacity		:	0.8			//Opacity for overlay (0-1)
				});
				
				$('.fade').mosaic();
				
				$('.bar').mosaic({
					animation	:	'slide'		//fade or slide
				});
				
				$('.bar2').mosaic({
					animation	:	'slide'		//fade or slide
				});
				
				$('.bar3').mosaic({
					animation	:	'slide',	//fade or slide
					anchor_y	:	'top'		//Vertical anchor position
				});
				
				$('.cover').mosaic({
					animation	:	'slide',	//fade or slide
					hover_x		:	'400px'		//Horizontal position on hover
				});
				
				$('.cover2').mosaic({
					animation	:	'slide',	//fade or slide
					anchor_y	:	'top',		//Vertical anchor position
					hover_y		:	'80px'		//Vertical position on hover
				});
				
				$('.cover3').mosaic({
					animation	:	'slide',	//fade or slide
					hover_x		:	'400px',	//Horizontal position on hover
					hover_y		:	'300px'		//Vertical position on hover
				});

		    
		    });
		    
		</script>
		

</head>

<!--Begin Body-->
<body class="home page page-id-369 page-template page-template-template-home-php wp-front-page">

<div id="page" class="hfeed">

<!--Begin Header-->
<header id="site-head">
	<div class="clearfix col-box">
	<div class="site-logo">
<a href="index.html"><img src="images/GMP_Logo.png" width="287" height="117" /></a>
</div>

		      <div class="site-logo2">
<a href="http://www.globallinkmp.com/pre-registration-page/" target="_blank"><img src="images/pre-reg.png" width="300" height="45"></a><br><img src="images/proposal.png" width="300" height="45">
      </div>
	</div><!--End Header-->
</header>
<div id='cssmenu'>

<ul><li><a href="index.html">HOME</a></li>
<li><a href="shows.php">EVENTS</a>
</li>
<li class='active'><a href="services.php">SERVICES</a>
</li>
<li><a href="#">PORTFOLIO</a>
</li>
<li><a href="#">NEWS</a>
</li>
<li><a href="about_us.php">ABOUT US</a></li>
<!--<li id="menu-item-596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-596"><a href="feature.html">SPECIAL FEATURE</a></li>-->

<li><a href="contacts.php">CONTACT US</a></li>
</ul></div>
</div>
<!--<div id="page2">
  <img src="images/landing_banner.jpg" width="1264" height="239"></div>-->

<div id="page" class="hfeed"><div id="main" class="fullwidth">

<!--Begin Content-->
<article id="content"><img src="images/landing_banner.jpg" width="990" height="166"><!--end slides-wrap-->
<div class="col-box home-service-box clearfix"><div class="col-1-4 col-first clearfix"><h1 class="title"><br>OUR LINE OF SERVICES</h1>

<form name="digi_form" method="post" action="">
<style type="text/css">span.wpcf7-list-item { display: block; } table {width:900px !important;}</style>
<p><span><input type="hidden" class="wpcf7-form-control wpcf7-text" size="40" value="Consumer Electronics World 2015" name="Event"></span><br>
Note: <font color="red">All fields are required.</font></p><br>
<table>
<tbody><tr>
<td colspan="3">
<h3>Personal Information</h3><hr>
</td>
</tr>
<tr>
<td width="56%" height="55">First Name:<font color="red">*</font><br><span><input type="text" size="34" value="" name="FirstName" required /></span> </td>
<td colspan="2">Last Name:<font color="red">*</font><br><span><input type="text" size="34" value="" name="LastName" required /></span></td>
</tr>
<tr>
<td height="78"><br>Designation:<font color="red">*</font><br><span><input type="text" size="34" value="" name="Designation" required ></span></td>
<td width="29%"><br>Send my email confirmation to:<font color="red">*</font><br><span><input type="text" size="34" value="" name="VisitorsEmail"required ></span><span>
<p style="font-style:italic; font-size:0.8em; line-height:100%;">Important: Kindly make sure that you have entered the correct email <br> address in order to validate your pre-registration. Thank you.</p></span>
</td>
<td width="15%">&nbsp;</td>
</tr>
<tr>
<td><br>Mobile:<font color="red">*</font><br><span><input type="text" size="34" value="" name="Mobile" required></span></td>
<td colspan="2"><br>Phone:<font color="red">*</font><br><span><input type="text" size="34" value="" required name="Phone"></span></td>
</tr>
<tr>
<td height="34" colspan="3">&nbsp;

</td>
</tr>
<tr>
<td colspan="3">
<h3>Company Details</h3><hr>
</td>
</tr>
<tr>
<td height="52">Company Name:<font color="red">*</font><br><span><input type="text" size="34" value="" name="CompanyName" required></span></td>
<td colspan="2">Address:<i>(Building name, Street Address and Barangay, etc.)</i>: <font color="red">*</font><br><span><input type="text" size="34" value="" name="Address" required></span></td>
</tr>
<tr>
<td><br>City/State:<font color="red">*</font><br><span><input type="text" size="34" value="" name="CityState" required></span></td>
<td colspan="2"><br>Postal/Zip Code:<font color="red">*</font><br><span><input type="text" size="34" value="" name="Zipcode" required></span></td>
</tr>
<tr>
<td height="47" style="vertical-align:central;"><br>Fax:<br><span><input type="text" size="34" value="" name="Fax"></span></td>
<td colspan="2"><br>Country:<font color="red">*</font> <span><br><select name="country"><option value="Philippines">Philippines</option><option value="Afghanistan">Afghanistan</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Antigua &amp; Deps">Antigua &amp; Deps</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia Herzegovina">Bosnia Herzegovina</option><option value="Botswana">Botswana</option><option value="Brazil">Brazil</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina">Burkina</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Central African Rep">Central African Rep</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Congo {Democratic Rep}">Congo {Democratic Rep}</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Denmark">Denmark</option><option value="Djibouti">Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Greece">Greece</option><option value="Grenada">Grenada</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Honduras">Honduras</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Ireland {Republic}">Ireland {Republic}</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Ivory Coast">Ivory Coast</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Korea North">Korea North</option><option value="Korea South">Korea South</option><option value="Kosovo">Kosovo</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia">Malaysia</option><option value="Maldives">Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mexico">Mexico</option><option value="Micronesia">Micronesia</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar, {Burma}">Myanmar, {Burma}</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands">Netherlands</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Qatar">Qatar</option><option value="Romania">Romania</option><option value="Russian Federation">Russian Federation</option><option value="Rwanda">Rwanda</option><option value="St Kitts &amp; Nevis">St Kitts &amp; Nevis</option><option value="St Lucia">St Lucia</option><option value="Saint Vincent &amp; the Grenadines">Saint Vincent &amp; the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Sudan">South Sudan</option><option value="Spain">Spain</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tonga">Tonga</option><option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Tuvalu">Tuvalu</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City">Vatican City</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option></select></span></td>
</tr>
<tr>
<td height="62"><br>Product Line:<br><span><input type="text" class="wpcf7-form-control wpcf7-text" size="34" value="" name="pLine"></span></td>
<td colspan="2"><br>Website:<br><span><input type="text" size="34" value="" name="Website"></span></td>
</tr>
<tr>
<td height="38" colspan="3">&nbsp;

</td>
</tr>
<tr>
<td colspan="3">
<h3>Visitor Survey</h3><hr>
</td>
</tr>
</tbody></table>
<table>
<tr>
	<td width="4"><br>
	        </td>
	<td colspan="2"><strong>1. Specific show of interest:<font color="red">*</font></strong><br>
                 <div class="rowElem"><input type="checkbox" value="Consumer Entertainment" name="interest[]"><label>&nbsp;Consumer Entertainment</label></div><div class="rowElem"><input type="checkbox" tabindex="1" value="Consumer Home" name="interest[]"><label>&nbsp;Consumer Home</label></div>
<div class="rowElem"><input type="checkbox" tabindex="2" value="Consumer Lifestyle" name="interest[]"><label>&nbsp;Consumer Lifestyle</label></div><div class="rowElem"><label>Others, please specify: </label></div><div class="rowElem"><input type="text" class="wpcf7-form-control wpcf7-text" size="20" value="" name="interest[]" style="border-top:solid 0px #000000; border-left:solid 0px #000000; border-right:solid 0px #000000; border-bottom:solid 1px #000000; display:inline;"></div></td>
	<td colspan="3">&nbsp;</td>
	</tr>
  <td height="21">&nbsp;</td>
  <td width="24" valign="bottom">&nbsp;</td>
  <td width="408" valign="bottom">&nbsp;</td>
  <td width="482" valign="bottom">&nbsp;</td>
  <td width="-1" valign="bottom">&nbsp;</td>
  <td width="5" valign="bottom">&nbsp;</td>
  </tr>
<tr>
  <td height="22">&nbsp;</td>
  <td colspan="2" valign="bottom"><strong>2. Purpose of visit:</strong><font color="red">*</font></td>
  <td valign="bottom">&nbsp;</td>
  <td valign="bottom">&nbsp;</td>
  <td valign="bottom">&nbsp;</td>
  </tr>
<tr>
  <td height="22">&nbsp;</td>
  <td height="22"><span class="wpcf7-list-item">
    <input type="checkbox" value="Gather information" name="visitPurpose[]">
  </span></td>
  <td height="22"><span class="wpcf7-list-item"><span class="wpcf7-list-item-label">Gather information</span></span></td>
  <td colspan="2" rowspan="2">&nbsp;</td>
  <td height="22">&nbsp;</td>
  </tr>
<tr>
  <td height="10">&nbsp;</td>
  <td height="10"><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="1" value="Make purchase on site" name="visitPurpose[]">
  </span></td>
  <td height="10"><span class="wpcf7-list-item"><span class="wpcf7-list-item-label">Make purchase on site</span></span></td>
  <td height="10">&nbsp;</td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="4" value="Evaluate show for future participation" name="visitPurpose[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>Evaluate show for future participation</label>
  </span></span></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
	<td><br>
	        </td>
	<td colspan="2" rowspan="2">Others, please specify: <br>
	  <span>
      <input type="text" class="wpcf7-form-control wpcf7-text" size="20" value="" name="visitPurpose[]" style="border-top:solid 0px #000000; border-left:solid 0px #000000; border-right:solid 0px #000000; border-bottom:solid 1px #000000; display:inline;">
      </span></td>
	<td colspan="2">&nbsp;</td>
	<td>&nbsp;</td>
    </tr>
<tr>
  <td height="22">&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="22">&nbsp;</td>
  <td valign="bottom">&nbsp;</td>
  <td valign="bottom">&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="22">&nbsp;</td>
  <td colspan="2" valign="bottom"><strong>3. Source of information about the event (choose all that apply):<font color="red">*</font></strong></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="22">&nbsp;</td>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" value="Print advertisement" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>Print advertisement</label>
  </span></span></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr><tr>
  <td height="22">&nbsp;</td>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="1" value="Direct mail from an Organizer" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>Direct mail from an Organizer</label>
  </span></span></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr><tr>
  <td height="22">&nbsp;</td>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="2" value="Direct mail from an Exhibitor" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>Direct mail from an Exhibitor</label>
  </span></span></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="21">&nbsp;</td>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="3" value="Direct mailer from an association Please specify:" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>Direct mailer from an association</label>
  </span></span></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="22">&nbsp;</td>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" value="Billboard / Outdoor advertisements" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>Billboard</label>
  </span></span></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="22">&nbsp;</td>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="1" value="Emailed invitation" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>Emailed invitation</label>
  </span></span></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="22" rowspan="8">&nbsp;</td>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="2" value="Website" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>Website</label>
  </span></span></td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td rowspan="8">&nbsp;</td>
</tr>
<tr>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="3" value="TV / Radio" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item">&nbsp;<span class="wpcf7-list-item-label">
    <label>TV / Radio</label>
  </span></span></td>
  <td height="24">&nbsp;</td>
  <td height="24">&nbsp;</td>
</tr>
<tr>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="4" value="Text / SMS info" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item"><span class="wpcf7-list-item-label">
    <label>Text / SMS info</label>
  </span></span></td>
  <td colspan="2" rowspan="6">&nbsp;</td>
  </tr>
<tr>
  <td><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="5" value="Friend / colleague" name="infoSource[]">
  </span></td>
  <td><span class="wpcf7-list-item"><span class="wpcf7-list-item-label">
    <label>Friend / colleague</label>
  </span></span></td>
  </tr>
<tr>
  <td height="24"><span class="wpcf7-list-item">
    <input type="checkbox" tabindex="7" value="Social Networking Site" name="infoSource[]">
  </span></td>
  <td height="24"><span class="wpcf7-list-item"><span class="wpcf7-list-item-label">
    <label>Social Networking Sites</label>
  </span></span></td>
  </tr>
<tr>
  <td height="5" colspan="2">Others, please specify:<br>
    <span>
    <input type="text" class="wpcf7-form-control wpcf7-text" size="20" value="" name="infoSource[]" style="border-top:solid 0px #000000; border-left:solid 0px #000000; border-right:solid 0px #000000; border-bottom:solid 1px #000000; display:inline;">
    </span></td>
  </tr>
<tr>
  <td height="5">&nbsp;</td>
  <td height="5">&nbsp;</td>
</tr>
<tr>
  <td height="5" colspan="2"><strong>4. I would like to receive updates on upcoming shows:<font color="red">*</font></strong><br>
	       <div class="rowElem"><input type="checkbox" value="Yes" name="update[]" onClick="return disablefields();" id="checkboxA"><label>&nbsp;Yes</label></div><div class="rowElem"><input type="checkbox" tabindex="1" value="No" name="update[]" onClick="return fields();" id="checkboxB"><label>&nbsp;No</label></div><br></td>
  </tr>
<tr>
  <td height="21">&nbsp;</td>
  <td height="21">&nbsp;</td>
  <td height="21" align="left"></td>
  <td height="21">&nbsp;</td>
  <td height="21">
  </td>
  <td height="21">&nbsp;</td>
</tr></table>
<table width="400" border="0" align="center" cellpadding="5" cellspacing="1" class="table">
    <tr>
      <td width="133" align="right" valign="top"> </td>
      <td width="834"></td>
    </tr>
    <tr>
      <td>  
 

 </td>
      <td></td>
    </tr>
    <tr>
                        <td colspan="2"><br><strong>Kindly fill up the captcha below before clicking submit button.</strong> <font color="red">*</font></td>
                    </tr>
                    <tr>
                        <td width="133">                           
                            <input type="text" name="captcha" id="captcha" maxlength="6" size="10"/></td>
                        <td><img width="70" height="30" src="captcha.php"/></td>
                    </tr>
  </table>
<br>
<span class="rowElem">
    <input type="submit" name="submit" value="Submit" /></span>
<span><input type="hidden" size="40" class="wpcf7-text" value="DPH0HA3T" name="ticket"></span></p>
<div class="wpcf7-response-output wpcf7-display-none"></div>
</form>
</div></div>
</article><br><br>
<!--End Content-->


<!-- #main -->
<footer>

<!--Begin Footer Widget--><!--End Footer Widget-->

<div class="footer-message">

Copyright &copy; - GLOBAL-LINK EXHIBITIONS SPECIALIST, INC. - MIS.
</div>
<!--end # footer message-->
<!--End Footer-->
</footer>
</div></div>
<!-- # page -->

<div id="toTop">Back to top</div>


	<div style="display:none">
	</div>
<script type="text/javascript">
//<![CDATA[
ddsmoothmenu.init({
mainmenuid: "top-menu", 
orientation: "h", 
classname: "ddsmoothmenu", 
contentsource: "markup" 
});
//]]>
</script>

<script type='text/javascript' src='js/jquery.form.js'></script>



<script src="js/e-201319.js" type="text/javascript"></script>
<script type="text/javascript">
	st_go({v:'ext',j:'1:1.4.2',blog:'38302682',post:'369'});
	var load_cmc = function(){linktracker_init(38302682,369,2);};
	if ( typeof addLoadEvent != 'undefined' ) addLoadEvent(load_cmc);
	else load_cmc();
	</script><!--End Body-->
</body>

<!--End Html-->
</html>