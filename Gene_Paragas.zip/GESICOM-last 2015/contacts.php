<!doctype html>

<!--Begin Html-->
<html dir="ltr" lang="en-US">

<!--Begin Head-->
<head>

<!--Meta Tags-->
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />

<title>Global-Link Exhibitions Specialist, Inc.</title>


<link rel='stylesheet' id='contact-form-7-css'  href='css/style2.css' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='css/style.css' type='text/css' media='screen' />
<link rel='stylesheet' id='slideshow-css'  href='css/slideshow.css' type='text/css' media='screen' />
<link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css' type='text/css' media='screen' />
<link rel='stylesheet' id='shortcodes-css'  href='css/shortcodes.css' type='text/css' media='screen' />
<link rel='stylesheet' id='widgets-css'  href='css/widgets.css' type='text/css' media='screen' />
<link rel='stylesheet' id='prettyphoto-css'  href='css/prettyphoto.css' type='text/css' media='screen' />
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery.scripts.js'></script>
<script type='text/javascript' src='js/html5.min.js'></script>
<script type='text/javascript' src='js/custom.js'></script>
   <script src="script.js"></script>
   <link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="jquery.motionCaptcha.0.2.css?ez_orig=1"/>
<!--Extend CSS-->
<style type="text/css">

	#slides-wrap-home .slider-pagination { left: 400px; }
		.site-logo, .site-name { margin-top: 0px; margin-bottom: 0px; }
		.top-media { margin-top: 45px; }
		.ddsmoothmenu ul li ul li a { width: 160px; }
		body { font-family: "Helvetica Neue", Arial, Helvetica, sans-serif; }
		nav { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		h1, h2, h3, h4, h5, h6 { font-family: "Open Sans", Helvetica, Arial, serif, sans-serif; }
		.meta { font-family: "Mako", Helvetica, Arial, serif, sans-serif; }
		#top-menu ul.drop-menu li a { font-size: 14px; font-weight:bold; }
		#top-menu ul.drop-menu li ul li a { font-size: 12px; }
		.post-content h1  { font-size: 24px; }
		.post-content h2  { font-size: 20px; }
		.post-content h3  { font-size: 16px; }
		.post-content h4  { font-size: 14px; }
		.post-content h5  { font-size: 12px; }
		.post-content h6  { font-size: 10px; }
		body { color: #666666; }
		a { color: #333333; }
		a:hover,
		#top-menu ul.drop-menu li a:hover,
		#top-menu ul.drop-menu li a.selected,
		#top-menu ul.drop-menu li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-item a,
		#top-menu ul.drop-menu li.current_page_parent a,
		#top-menu ul.drop-menu li.current-menu-parent a,
		.blog-list li .post-meta a:hover,
		.post-blog-single .post-meta a:hover,
		.comment-meta .fn a:hover,
		.comment-form-author span,
		.comment-form-email span,
		.widget-tweets li .date a:hover,
		.widget-posts li .post-meta a:hover,
		.widget-portfolios li .post-meta a:hover,
		.sc-slider-list li .meta a:hover,
		.sc-slider-list li .skills a:hover,
		.home-service-box .title,
		.commentlist li .reply:hover,
		.sc-pricing-table-wrap .pricing-item .price-currency { color: #f56622; }
		.post-more a:hover,
		.blog-list li .more-link:hover,
		.post-portfolio-single .single-post-pagenation li a:hover,
		.comment-form-author input[type="text"]:focus,
		.comment-form-email input[type="text"]:focus,
		.comment-form-url input[type="text"]:focus,
		#commentform .comment-form-comment:focus,
		#commentform .form-submit input[type="submit"]:hover,
		.wp-pagenavi a:hover, 
		.wp-pagenavi span.current,
		.pagination a:hover,
		.pagination span.current,
		.normal-pagination span a:hover,
		.comment-pagination a:hover, 
		.comment-pagination span.current,
		.sortable-menu li.current-cat a,
		.sortable-menu li.active a,
		.sortable-menu li a:hover,
		.post-single-contact .input-block input:focus,
		.post-single-contact .textarea-block #contact-message:focus,
		.post-single-contact .submit-block input[type="submit"]:hover,
		.jcarousel-prev:hover, .jcarousel-prev:focus, .jcarousel-prev:active,
		.jcarousel-next:hover, .jcarousel-next:focus, .jcarousel-next:active,
		.sc-tabs-wrap .tabs li .active,
		.sc-pricing-table-wrap .pricing-item .button-wrap a:hover { background-color: #4e2350; }
		.jcarousel-prev-disabled, .jcarousel-prev-disabled:hover,
		.jcarousel-prev-disabled:focus, .jcarousel-prev-disabled:active,
		.jcarousel-next-disabled, .jcarousel-next-disabled:hover,
		.jcarousel-next-disabled:focus, .jcarousel-next-disabled:active { background-color: #EEE; }
		.post-thumb-border .border { border: 5px solid #4e2350; }

		#top-menu ul.drop-menu li.current_page_parent ul li a,
		#top-menu ul.drop-menu li.current-menu-parent ul li a { color: #333; }

		#top-menu ul.drop-menu li.current_page_parent ul li.current_page_item a,
		#top-menu ul.drop-menu li.current-menu-parent ul li.current-menu-item a { color: #fff; }
		

			body { background: url(images/bg_new1.jpg) no-repeat center center fixed #161616; -webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover; } 

.details{ margin:15px 20px; }			
h4{ font:300 16px 'Helvetica Neue', Helvetica, Arial, sans-serif; line-height:140%; color:#fff; text-shadow:1px 1px 0 rgb(0,0,0); }
					p{ font:300 12px 'Lucida Grande', Tahoma, Verdana, sans-serif; color:#aaa; text-shadow:none;}
					a{ text-decoration:none; }
					
					#mc-canvas {
    margin:0 auto 10px;
    padding:1px;
    display: block;
    border: 4px solid #433e45;
    -webkit-border-radius: 4px;
       -moz-border-radius: 4px;
            border-radius: 4px;
}
/* Red border when invalid */
#mc-canvas.mc-invalid {
    border: 4px solid #aa4444;
}
/* Green border when valid */
#mc-canvas.mc-valid {
    border: 4px solid #44aa44;
}			
			
</style>

		<!--Custom CSS-->
		
		<link type="text/css" rel="stylesheet" href="css/custom.css" media="screen" />
		<link href='css/css2.css' rel='stylesheet' type='text/css'>
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="shortcut icon" href="images/fav-iffina.png" />

<!--End head-->


</head>

<!--Begin Body-->
<body class="home page page-id-369 page-template page-template-template-home-php wp-front-page">

<div id="page" class="hfeed">

<!--Begin Header-->
<header id="site-head">
	<div class="clearfix col-box">
	<div class="site-logo">
<a href="index.html"><img src="images/GMP_Logo.png" width="287" height="117" /></a>
</div>

<div class="site-logo2">
<a href="http://www.globallinkmp.com/pre-registration-page/" target="_blank"><img src="images/pre-reg.png" width="300" height="45"></a><br><img src="images/proposal.png" width="300" height="45">
      </div>
	</div><div class="col-2-2 col-first clearfix">
	</div><!--End Header-->
</header>
<div id='cssmenu'>

<ul><li><a href="index.html">HOME</a></li>
<li><a href="shows.php">EVENTS</a>
</li>
<li><a href="services.php">SERVICES</a>
</li>
<li><a href="#">PORTFOLIO</a>
</li>
<li><a href="#">NEWS</a>
</li>
<li><a href="about_us.php">ABOUT US</a></li>
<!--<li id="menu-item-596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-596"><a href="feature.html">SPECIAL FEATURE</a></li>-->

<li  class='active'><a href="contacts.php">CONTACT US</a></li>
</ul></div>
</div>
<!--<div id="page2">
  <img src="images/landing_banner.jpg" width="1264" height="239"></div>-->
<div id="page" class="hfeed"><div id="main" class="fullwidth">

<!--Begin Content-->
<article id="content"><img src="images/landing_banner.jpg" width="990" height="166"><!--end slides-wrap-->
<div class="col-box home-service-box clearfix"><div class="col-2-1 col-first clearfix"><br>
  <table width="300" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2">
<img src="images/GESI logo.png"><br>
GLOBAL-LINK EXHIBITIONS SPECIALIST, INC.<br>
3973 Yague Street 
Brgy. Sta. Cruz, Makati City, Philippines 1205<br>
Tel. No. : (+63 2) 893-7973<br>
Fax No. : (+63 2) 550-1148<br>
Email: <a href="mailto:info@gesi.com.ph" style="text-decoration:underline;">info@gesi.com.ph</a>
<br>
</td></tr></table></p>
  <h1 class="title">&nbsp;</h1></div><div class="col-2-1 clearfix">
<form action="form_inquiry.php" method="post" id="mc-form" class="basic-grey">
    <h1 class="title" style="font-size:20px;">Contact Form 
        <span>Please fill all the texts in the fields.</span>
    </h1>
    <label>
        <span>Your Name :</span>
        <input id="name" type="text" name="name" placeholder="Your Full Name" />
    </label>

    <label>
        <span>Your Email :</span>
        <input id="email" type="email" name="email" placeholder="Valid Email Address" />
    </label>

    <label>
        <span>Message :</span>
        <textarea id="message" name="message" placeholder="Your Message to Us"></textarea>
    </label>
     <label>
        <span>Subject :</span><select name="subject">
        <option value="Business Proposal">Business Proposal</option>
        <option value="General Question">General Question</option>
        </select>
    </label>   
     <label>
       <center><span>Please draw the shape in the box to submit the form: (<a onclick="window.location.reload()" href="#" title="Click for a new shape">new shape</a>)</span>
  <canvas id="mc-canvas">
    Your browser doesn't support the canvas element - please visit in a modern browser.
</canvas>  </center>
    </label>   
     <label>
        <span>&nbsp;</span> 
      
        <input type="submit" value="Submit" disabled="disabled">
    </label>    
</form>

</div><br><br><br><br></div><div style="margin-top: 20px;"></div>
</article><br>
<!--End Content-->


<!-- #main -->
<footer>

<!--Begin Footer Widget--><!--End Footer Widget-->

<div class="footer-message">

Copyright &copy; - GLOBAL-LINK EXHIBITIONS SPECIALIST, INC. - MIS.
</div>
<!--end # footer message-->
<!--End Footer-->
</footer>
<!-- # page -->
</div></div>
<div id="toTop">Back to top</div>


	<div style="display:none">
	</div>
<script type="text/javascript">
//<![CDATA[
ddsmoothmenu.init({
mainmenuid: "top-menu", 
orientation: "h", 
classname: "ddsmoothmenu", 
contentsource: "markup" 
});
//]]>
</script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" type="text/javascript"></script>
<script src="jquery.motionCaptcha.0.2.js" ></script>
<script type="text/javascript">
        jQuery(document).ready(function($) {
            // Do the biznizz:
            $('#mc-form').motionCaptcha({
                shapes: ['triangle', 'x', 'rectangle', 'circle', 'check', 'zigzag', 'arrow', 'delete', 'pigtail', 'star']
            });
 
        });
    </script>
<script type='text/javascript' src='js/jquery.form.js'></script>



<script src="js/e-201319.js" type="text/javascript"></script>
	<script type="text/javascript">
	st_go({v:'ext',j:'1:1.4.2',blog:'38302682',post:'369'});
	var load_cmc = function(){linktracker_init(38302682,369,2);};
	if ( typeof addLoadEvent != 'undefined' ) addLoadEvent(load_cmc);
	else load_cmc();
	</script><!--End Body-->
</body>

<!--End Html-->
</html>